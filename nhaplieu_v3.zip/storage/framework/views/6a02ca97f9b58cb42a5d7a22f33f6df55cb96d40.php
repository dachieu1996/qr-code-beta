<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Đại Lý
                        <small><?php echo e($daily->TenDL); ?></small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12" style="padding-bottom:120px">
                    <div class="col-lg-6">
                        <form action="admin/daily/sua/<?php echo e($daily->MaDL); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <?php if(session('thongbao')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('thongbao')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('canhbao')): ?>
                                <div class="alert alert-warning">
                                    <?php echo e(session('canhbao')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label>Mã Đại Lý</label>
                                <input class="form-control" name="MaDL" placeholder="Điền mã sản phẩm" readonly value="<?php echo e($daily->MaDL); ?>" />
                            </div>

                            <div class="form-group">
                                <label>Tên Đại Lý</label>
                                <input class="form-control" name="TenDL" placeholder="Điền tên sản phẩm" value="<?php echo e($daily->TenDL); ?>" />
                            </div>

                            <button type="submit" class="btn btn-default">Sửa</button>
                        </form>
                    </div>
                </div>


            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>