<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Sản Phẩm
                        <small><?php echo e($sanpham->TenSP); ?></small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12" style="padding-bottom:120px">
                    <div class="col-lg-6">
                        <form action="admin/sanpham/sua/<?php echo e($sanpham->MaSP); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <?php if(session('thongbao')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('thongbao')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('canhbao')): ?>
                                <div class="alert alert-warning">
                                    <?php echo e(session('canhbao')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label>Mã Sản Phẩm</label>
                                <input class="form-control" name="MaSP" placeholder="Điền mã sản phẩm" readonly value="<?php echo e($sanpham->MaSP); ?>" />
                            </div>

                            <div class="form-group">
                                <label>Tên sản phẩm</label>
                                <input class="form-control" name="TenSP" placeholder="Điền tên sản phẩm" value="<?php echo e($sanpham->TenSP); ?>" />
                            </div>

                            <div class="form-group">
                                <label>Số đăng ký</label>
                                <input class="form-control" name="SDK" placeholder="Điền Số đăng ký" value="<?php echo e($sanpham->SDK); ?>" />
                            </div>

                            <div class="form-group">
                                <label>Hình ảnh</label>
                                <input id="HinhAnh" type="file" onchange="readURL(this);" accept="image/*" class="form-control sanpham" name="HinhAnh" placeholder="Nhập hình ảnh" />
                            </div>

                            <button type="submit" class="btn btn-default">Sửa</button>
                        </form>
                    </div>
                    <div class="col-lg-6">
                        <div align="center">
                            <img id="imgHinhAnh" src="upload/sanpham/<?php echo e($sanpham->HinhAnh); ?>" width="400px" >
                        </div>
                    </div>
                </div>


            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imgHinhAnh')
                        .attr('src', e.target.result)
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>