<?php $__env->startSection('content'); ?>
    <<div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Sản Phẩm
                        <small>Danh Sách</small>
                        <small>
                            <a href="admin/sanpham/them" class="btn btn-default" target="_blank">Thêm dữ liệu</a>
                        </small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->

                <?php if(session('thongbao')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('thongbao')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('canhbao')): ?>
                    <div class="alert alert-warning">
                        <?php echo e(session('canhbao')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('nguyhiem')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('nguyhiem')); ?>

                    </div>
                <?php endif; ?>

                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                    <tr align="center">
                        <th>Mã SP</th>
                        <th>Tên</th>
                        <th>SĐK</th>
                        <th>Hình ảnh</th>
                        <th>Sửa</th>
                        <th>Xóa</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX" align="center">
                            <td><?php echo e($sp->MaSP); ?></td>
                            <td><?php echo e($sp->TenSP); ?></td>
                            <td><?php echo e($sp->SDK); ?></td>
                            <td>
                                <img width="100px" src="upload/sanpham/<?php echo e($sp->HinhAnh); ?>"/>
                            </td>
                            <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/sanpham/sua/<?php echo e($sp->MaSP); ?>" target="_blank">Sửa</a></td>
                            <td class="center"><i class="fa fa-remove fa-fw"></i> <a href="admin/sanpham/xoa/<?php echo e($sp->MaSP); ?>">Xóa</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>