<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Thông tin Lô sản xuất Sản Phẩm
                        <small></small>
                    </h1>
                </div>


                <div class="col-lg-12" style="padding-bottom:120px">
                    <div class="col-lg-6" >
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($error); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if(session('thongbao')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('thongbao')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('canhbao')): ?>
                            <div class="alert alert-warning">
                                <?php echo e(session('canhbao')); ?>

                            </div>
                        <?php endif; ?>
                            <div class="form-group">
                                <label>Mã Lô:  </label>
                                <input class="form-control" name="MaLo" readonly value="<?php echo e($thongtin['MaLo']); ?>"/>
                            </div>
                            <div class="form-group">
                                <label>Mã Sản Phẩm:  </label>
                                <input class="form-control" name="MaSP" readonly value="<?php echo e($thongtin['MaSP']); ?>"/>
                            </div>
                            <div class="form-group">
                                <label>Tên Sản Phẩm: </label>
                                <input class="form-control" name="TenSP" readonly value="<?php echo e($thongtin['TenSP']); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Số Đăng Ký: </label>
                                <input class="form-control" name="SDK" readonly value="<?php echo e($thongtin['SDK']); ?>"/>
                            </div>
                            <div class="form-group">
                                <label>Ngày Sản Xuất: </label>
                                <input class="form-control" name="NSX" readonly value="<?php echo e($thongtin['NSX']); ?>"/>
                            </div>
                            <div class="form-group">
                                <label>Hạn sử dụng: </label>
                                <input class="form-control" name="HSD" readonly value="<?php echo e($thongtin['HSD']); ?>"/>
                            </div>
                            <div class="form-group">
                                <label>Số lượng: </label>
                                <input class="form-control" name="SoLuong" readonly value="<?php echo e($thongtin['SoLuong']); ?>"/>
                            </div>
                    </div>
                    <div class="col-lg-6"style="padding-bottom:20px">
                        <div align="center">
                            <img id="imgHinhAnh" src="upload/sanpham/<?php echo e($thongtin['HinhAnh']); ?>" width="300px" >
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr align="center">
                                <th>Tên Đại lý</th>
                                <th>Số sản phẩm</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php for($i=0; $i<count($thongtin['MaDL']);$i++): ?>
                                <input type="hidden" name="MaDL[]" value="<?php echo e($thongtin['MaDL'][$i]); ?>">
                                <input type="hidden" name="TenDL[]" value="<?php echo e($thongtin['TenDL'][$i]); ?>">
                                <input type="hidden" name="SoSP[]" value="<?php echo e($thongtin['SoSP'][$i]); ?>">
                                <tr class="odd gradeX" align="center">
                                    <td><?php echo e($thongtin['TenDL'][$i]); ?></td>
                                    <td><?php echo e($thongtin['SoSP'][$i]); ?></td>
                                </tr>
                            <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>

                </div>





            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('#MaLo').keyup(function () {
                var MaLo = $(this).val();
                $.get("admin/ajax/TenSP/"+MaLo,function (data) {
                    $("#TenSP").html(data);
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>