<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaiLy extends Model
{
    //
    protected $table = 'daily';
    protected $primaryKey = 'MaDL';
    protected $keyType = 'string';
}
