<?php $__env->startSection('content'); ?>
    <<div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Đại lý
                        <small>Danh Sách</small>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
                <?php if(session('thongbao')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('thongbao')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('canhbao')): ?>
                    <div class="alert alert-warning">
                        <?php echo e(session('canhbao')); ?>

                    </div>
                <?php endif; ?>

                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                    <tr align="center">
                        <th>Mã Đại Lý</th>
                        <th>Tên Đại Lý</th>
                        <th>Sửa</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX" align="center">
                            <td><?php echo e($dl->MaDL); ?></td>
                            <td><?php echo e($dl->TenDL); ?></td>
                            <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/daily/sua/<?php echo e($dl->MaDL); ?>" target="_blank">Sửa</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>